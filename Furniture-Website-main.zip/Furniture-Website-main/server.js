const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://<Furkan>:<1234>@furkan.jc6re51.mongodb.net/?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB Connected'))
  .catch((err) => console.log('MongoDB Connection Error:', err));
  const SERVER_URL = 'http://localhost:3000'; // Sunucu URL'si

// Ürünleri getir
async function getProducts() {
  const response = await fetch(`${SERVER_URL}/api/products`);
  const products = await response.json();
  // ...
}

// Sepete ekle
function addToCart(product) {
  const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  // ...
}

// Sepeti getir
function getCartItems() {
  const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
  // ...
}
