// Ürünü sepete ekle
function addToCart(product) {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    cartItems.push(product);
    localStorage.setItem('cartItems', JSON.stringify(cartItems));
  }
  
  // Sepete ekle düğmesi tıklama olayını işle
  document.addEventListener('click', e => {
    if (e.target && e.target.classList.contains('add-to-cart-btn')) {
      const product = e.target.parentNode;
      const productName = product.querySelector('.product-name').textContent;
      const productPrice = product.querySelector('.product-price').textContent.slice(1);
      const productImage = product.querySelector('img').src;
  
      addToCart({ name: productName, price: productPrice, image: productImage });
    }
  });
  // Sepeti getir ve sayfada göster
function getCartItems() {
    const cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    const cartList = document.querySelector('.cart-list');
    cartList.innerHTML = '';
  
    // Sepeti listele
    cartItems.forEach(item => {
      const cartItem = document.createElement('div');
      cartItem.classList.add('cart-item');
      cartItem.innerHTML = `
        <img src="${item.image}" alt="${item.name}" />
        <div class="item-name">${item.name}</div>
        <div class="item-price">$${item.price}</div>
      `;
      cartList.appendChild(cartItem);
    });
  }
  
  window.addEventListener('DOMContentLoaded', () => {
    getCartItems();
  });
  